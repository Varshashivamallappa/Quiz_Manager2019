package fr.epita.questions.launcher;

import java.util.Scanner;
import fr.epita.questions.model.*;


public class Launcher {
	
	//The Execution Of Program starts from here

	
	public static void main(String[] args) {
		
		//The user needs to choose whether he is student or professor!
		
		int choice;
		System.out.println("Welcome To The Quiz Apllication!!\nEnter your choice\n1.Student\n2.Professor\n");
		
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		 choice = scanner.nextInt();
		 switch (choice) {
		case 1:
            Student stu = new Student();
			stu.studentoption();
			 break;
			 
		case 2:
			Professor pro = new Professor();
			pro.professorOption();
			break;
			
		default:
			System.out.println("You have entered the wrong choice. Enter the correct choice:\n1.Student\n2.Professor\n");
			Scanner scanner1 = new Scanner(System.in);
			choice = scanner1.nextInt();
			
			break;	
		 }

	}

}
