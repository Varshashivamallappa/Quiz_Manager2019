package fr.epita.questions.model;


import java.util.Scanner;
import fr.epita.questions.service.QuestionsDAO;


public class Professor {
	
	private int questionId;
	private String quiz;
	private String question;
	private int difficulty;
	private String answer;
	
	private String a;
	private String b;
	private String c;
	private String d;
	private String yn;

	//takes professor inputs
	@SuppressWarnings("resource")
	public void professorOption() {
	int val;
	System.out.println("Select your choice:\n1.Create Quiz\n2.exit");
	Scanner scanner = new Scanner(System.in);
	val = scanner.nextInt();
	switch (val) {

	case 1:
		createques();
		break;
		
	case 2: System.out.println("Thank You!");
	       System.exit(0);
		break;
		
	default:
		System.out.println("You have entered the wrong choice. Enter the correct choice\\n1.Create Quiz\\n2.exit");
		Scanner scannerN = new Scanner(System.in);
		val = scannerN.nextInt();
		break;
	}

	}
	 
	//Professor Enters Quiz Details
	@SuppressWarnings("resource") 
	   public void createques(){
		
		System.out.println("Enter Quiz Name");
		Scanner scanner1 = new Scanner(System.in);
		quiz = scanner1.nextLine();

		boolean Continue = true;
		while(Continue) {
			
		System.out.println("Enter Question");
		Scanner scanner2 = new Scanner(System.in);
		question = scanner2.nextLine();
		
		System.out.println("Enter difficulty level(1/2/3)");
		Scanner scanner3 = new Scanner(System.in);
		difficulty = scanner3.nextInt();
		
		
		System.out.println("Enter options:");
		System.out.println("Option1:");
		Scanner scanner4 = new Scanner(System.in);
		a = scanner4.nextLine();
		System.out.println("Option2:");
		Scanner scanner5 = new Scanner(System.in);
		b = scanner5.nextLine();
		System.out.println("Option3:");
		Scanner scanner6 = new Scanner(System.in);
		c = scanner6.nextLine();
		System.out.println("Option4:");
		Scanner scanner7 = new Scanner(System.in);
		d = scanner7.nextLine();

		System.out.println("Enter Correct answer");
		Scanner scanner8 = new Scanner(System.in);
		answer = scanner8.nextLine();
		
		insert();
		System.out.println("Inserted");
		System.out.println("Do you want to add another Question? Yes or No\n");
		Scanner scanner9 = new Scanner(System.in);
		yn = scanner9.nextLine();
		
		if(yn.equalsIgnoreCase("yes")) {
			
		      Continue = true;	
		}
		else {
			System.out.println("Au Revoir");
			System.exit(0);
		}
	}
	}
	
	private void insert() {
		QuestionsDAO dao = new QuestionsDAO();
		dao.create(questionId, quiz, question, difficulty, answer, a, b, c, d);
	}
	
}

	

