package fr.epita.questions.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import fr.epita.questions.service.QuestionsDAO;

public class Student {
	
	private static QuestionsDAO dao;
	
	
	public Student() {
		
		dao = new QuestionsDAO();
	}
	
	public void studentoption() {

		//Enter Student Details
		
		System.out.println("Enter your name");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		@SuppressWarnings("unused")
		String name = scanner.nextLine();
			
		System.out.println("Enter Quiz Name You want to attend");
		String topic = scanner.nextLine();
		
		
		System.out.println("Enter difficulty level(1/2/3)");
		@SuppressWarnings("resource")
		Scanner scanner2 = new Scanner(System.in);
		int difficulty = scanner2.nextInt();
		
		
		System.out.println("Quiz will begin....\n ALL THE BEST!");
		 getQuestion_Id(topic, difficulty);
		 
	}
	
	// Gets the Questions based on difficulty and topics entered by the Student
	
	@SuppressWarnings("unchecked")
	private void getQuestion_Id(String topic, int difficulty) {
		String question = null;
		List<Integer> ids = new ArrayList<Integer>();
		ids = dao.getQuestion_Id(topic, difficulty);
		String[] choices = new String[5];
		int totalMarks=0;
		
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
	
		int ans;
		
		//Displays the questions to Student
		for(int i=0; i<ids.size();i++) {
			question = dao.getQuestions(ids.get(i));
			System.out.println((i+1)+" > "+question);
			
		//Displays Choices to Student	
			choices = dao.getChoices(ids.get(i));
			
			for(int j=0; j<choices.length-1; j++) {
				System.out.println((j+1)+"-"+choices[j]);
			}
			
			System.out.println("Enter the Choice");
			
			//Takes answer choice from Student
			ans = sc.nextInt();
			
			//Compares entered choice with correct choice
			if(choices[ans-1].equalsIgnoreCase(choices[4])) {
				totalMarks=totalMarks+1;
			}
			
		}
		//Displays Students Score at the end of Quiz
		System.out.println("Thank You For Attending the Quiz!\nYour Score is : " +totalMarks);
		
	}
}