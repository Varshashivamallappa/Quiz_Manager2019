package fr.epita.questions.service;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class Configuration {

	private static Configuration instance;
	
	private static final String defaultConfigFileLocation = "Config.properties";

	

	public static Configuration getInstance() {
		if (instance == null) {
			instance = new Configuration();
		}
		return instance;
	}
	
	Properties props = new Properties();
	boolean init = false;
	
	private Configuration() {
		// properties loading
		try {
			File confFile = new File("Config/config.properties");
			FileInputStream ips = new FileInputStream(confFile);
			props.load(ips);
			init =true;
		} catch (Exception e) {
			System.out.println(e);
			init=false;
		}

	}
	
	public boolean isInit() {
		return init;
	}



	public String getConfigurationValue(String key, String defaultValue) {
		return props.getProperty(key, defaultValue);
	}
	
}
