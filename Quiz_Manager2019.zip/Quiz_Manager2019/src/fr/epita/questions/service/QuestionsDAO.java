package fr.epita.questions.service;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import fr.epita.questions.service.Configuration;


//DAO To insert and get Data from the  Database
public class QuestionsDAO {
	
	Connection connection = null;
	PreparedStatement ptmt = null;
	ResultSet resultSet = null;
	private static String username="userName";
	private static String password="userPass";
	private static String url="userURL";
	
	
	
	public QuestionsDAO() {
		getConfig();
		try {
			connection=getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//Establishes connection with database
	public void getConfig() {
		Configuration conf = Configuration.getInstance();
		 username = conf.getConfigurationValue("userName", "s");
		 password = conf.getConfigurationValue("userPass", "");
		 url = conf.getConfigurationValue("userURL", "jdbc:h2:tcp://localhost/~/test");
		 
	}
	private Connection getConnection() throws SQLException {
		
		 connection = DriverManager.getConnection(url, username, password);
		return connection;
	}
	
	//Inserts Quiz details into the database entered by the Professor
	public void create(int question_id, String quiz, String question, int difficulty, String answer, String optiona, String optionb, String optionc, String optiond) {
				
		String INSERT_QUERY = "insert into questions(topics, question, difficulty, answer, optiona, optionb, optionc, optiond)\r\n" + 
				"values('"+quiz+"', '"+question+"', '"+difficulty+"','"+answer+"','"+optiona+"', '"+optionb+"', '"+optionc+"', '"+optiond+"')";

		try {		
			
		
		PreparedStatement pstmt = connection.prepareStatement(INSERT_QUERY); 
		pstmt.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println(sqle);
		}

	}
	
	//Gets Question IDs with difficulty and quiz name entered by the Student
	@SuppressWarnings("rawtypes")
	public List getQuestion_Id(String topics, int difficulty) {
		List<Integer> ids = new ArrayList<Integer>();
		String retrive = "select question_id from questions where topics='"+topics+"' and difficulty ="+difficulty;
		try {
			PreparedStatement pstm = connection.prepareStatement(retrive);
			
			ResultSet result = pstm.executeQuery();
			
			
			while(result.next()){
				ids.add(result.getInt("question_id"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ids;
		
	}
	
	//Gets All the questions based on the question Id
	public String getQuestions(int question_id) {
		String retrive = "select question from questions where question_id="+question_id;
		String question=null;
		try {
			PreparedStatement pstm = connection.prepareStatement(retrive);
			
			ResultSet result = pstm.executeQuery();
			
			
			while(result.next()){
				question =result.getString("question");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return question;
	}
	
	//Gets Choices for the related Questions
	public String[] getChoices(int question_id) {
		String retrive = "select optiona, optionb, optionc, optiond, answer from questions where question_id="+question_id;
		String[] choices = new String[5];
		
		try {
			PreparedStatement pstm = connection.prepareStatement(retrive);
			
			ResultSet result = pstm.executeQuery();
			
			
			while(result.next()){
				choices[0] =result.getString("optiona");
				choices[1] =result.getString("optionb");
				choices[2] =result.getString("optionc");
				choices[3] =result.getString("optiond");
				choices[4] =result.getString("answer");
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return choices;
	}
}
