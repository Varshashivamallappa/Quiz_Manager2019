package test;
import fr.epita.questions.service.QuestionsDAO;
public class TestDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		QuestionsDAO dao = new QuestionsDAO();
		dao.getConfig();
	}

}
