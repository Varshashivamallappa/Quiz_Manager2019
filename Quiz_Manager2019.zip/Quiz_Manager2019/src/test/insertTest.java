package test;
import fr.epita.questions.service.QuestionsDAO;

public class insertTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		QuestionsDAO dao= new QuestionsDAO();
		
		
		dao.create(3, "Q_name", "dasdasd", 1, "ds", "sa", "ds", "dsad", "asdasd");
	}

}
